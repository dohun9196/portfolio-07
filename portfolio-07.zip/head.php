<?php
if (!defined('_GNUBOARD_'))
    exit; // 개별 페이지 접근 불가


include_once(G5_THEME_PATH . '/head.sub.php');
include_once(G5_LIB_PATH . '/latest.lib.php');
include_once(G5_LIB_PATH . '/outlogin.lib.php');
include_once(G5_LIB_PATH . '/poll.lib.php');
include_once(G5_LIB_PATH . '/visit.lib.php');
include_once(G5_LIB_PATH . '/connect.lib.php');
include_once(G5_LIB_PATH . '/popular.lib.php');
?>

<body>
    <div class="Wrap">
        <header id="header">
            <div class="flex_inner h_flex">
                <h1>
                    <a href="/">
                        <img class="colr" src="<?php echo G5_THEME_URL ?>/img/main_page/header_logo.png" alt="">
                        <img class="white" src="<?php echo G5_THEME_URL ?>/img/main_page/header_logo_w.png" alt="">
                    </a>
                </h1>
                <nav class="gnb">
                    <?php
                    include G5_THEME_PATH . '/doc/nav.php';
                    ?>
                </nav>
                <div class="link">
                    <div class="mall">
                        <a href="#!">
                            <img class="colr" src="<?php echo G5_THEME_URL ?>/img/main_page/nav_mall.png" alt="">
                            <img class="white" src="<?php echo G5_THEME_URL ?>/img/main_page/nav_mall_w.png" alt="">
                        </a>
                    </div>
                    <div class="Nmall">
                        <a href="#!">
                            <img class="colr" src="<?php echo G5_THEME_URL ?>/img/main_page/nav_Nmall.png" alt="">
                            <img class="white" src="<?php echo G5_THEME_URL ?>/img/main_page/nav_Nmall_w.png" alt="">
                        </a>
                    </div>
                    <div class="naver">
                        <a href="https://blog.naver.com/vilacfood">
                            <img class="colr" src="<?php echo G5_THEME_URL ?>/img/main_page/nav_naver.png" alt="">
                            <img class="white" src="<?php echo G5_THEME_URL ?>/img/main_page/nav_naver_w.png" alt="">
                        </a>
                    </div>
                    <div class="facebook">
                        <a href="https://www.facebook.com/vilacfood">
                            <img class="colr" src="<?php echo G5_THEME_URL ?>/img/main_page/nav_facebook.png" alt="">
                            <img class="white" src="<?php echo G5_THEME_URL ?>/img/main_page/nav_facebook_w.png" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </header>