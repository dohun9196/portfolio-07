$(function () {
    $('.mainVisual .main_slide').slick({
        dots: true,
        autoplay: true,
        arrows: false,
        pauseOnHover: false,
        pauseOnFocus: false,
        autoplaySpeed: 4000,
        infinite: true,
        speed: 500,
        fade: true,
        cssEase: 'linear',
    });



    $(window).scroll(function () {
        var scrollValue = $(document).scrollTop();
        console.log(scrollValue);
    });

    $(window).scroll(function () {
        var height = $(document).scrollTop();

        if (height > 2) {
            $('#header').addClass('on');
        } else if (height < 2) {
            $('#header').removeClass('on');
        }
    });

    $('.inner.nav .ab_nav .head_gnb').on('click', function () {
        $('.inner.nav .ab_nav .head_gnb').toggleClass('on');
    });
    $('.inner.nav .ab_nav .ab_gnb').on('click', function () {
        $('.inner.nav .ab_nav .ab_gnb').toggleClass('on');
    });



    $('#header').hover(function () {
        $('#header').addClass('top');
    }, function () {
        $('#header').removeClass('top');

    });


    $('.sc_down a').click(function () {

        $('html, body').animate({ scrollTop: 846 }, 400);
        return false;
    });


    $('#top_btn a').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 400);
        return false;
    });


    $(window).scroll(function () {
        var height = $(document).scrollTop();
        if (height > 500) {
            $('#top_btn a').addClass('on');
        } else if (height < 500) {
            $('#top_btn a').removeClass('on');
        }

    });
});