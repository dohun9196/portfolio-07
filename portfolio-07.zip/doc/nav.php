<ul>
    <li><a href="<?php echo G5_THEME_URL ?>/doc/about01.php">About비락</a>
        <div class="menu_wrap">
            <ul class="h_drop">
                <li><a href="<?php echo G5_THEME_URL ?>/doc/about01.php">CEO 인사말</a></li>
                <li><a href="<?php echo G5_THEME_URL ?>/doc/about02.php">기업소개</a></li>
                <li><a href="<?php echo G5_THEME_URL ?>/doc/about03.php">연혁</a></li>
                <li><a href="<?php echo G5_THEME_URL ?>/doc/about04.php">CI소개</a></li>
                <li><a href="<?php echo G5_THEME_URL ?>/doc/about05.php">오시는길</a></li>
            </ul>
        </div>
    </li>
    <li><a href="<?php echo G5_THEME_URL ?>/doc/business01.php">BUSINESS</a>
        <div class="menu_wrap">
            <ul class="h_drop">
                <li><a href="<?php echo G5_THEME_URL ?>/doc/business01.php">유제품</a></li>
                <li><a href="<?php echo G5_THEME_URL ?>/doc/business02.php">음료</a></li>
            </ul>
        </div>
    </li>
    <li><a href="/bbs/board.php?bo_table=notice">News Room</a>
        <div class="menu_wrap">
            <ul class="h_drop">
                <li><a href="/bbs/board.php?bo_table=notice">비락소식</a></li>
                <li><a href="/bbs/board.php?bo_table=contribution">사회공헌</a></li>
                <li><a href="/bbs/board.php?bo_table=event">이벤트</a></li>
                <li id="blog"><a href="https://blog.naver.com/vilacfood" _target="_blank">비락 블로그</a></li>
                <li id="face"><a href="https://www.facebook.com/vilacfood" _target="_blank">비락 페이스북</a></li>
            </ul>
        </div>
    </li>
    <li><a href="<?php echo G5_THEME_URL ?>/doc/employment01.php">인재채용</a>
        <div class="menu_wrap">
            <ul class="h_drop">
                <li><a href="<?php echo G5_THEME_URL ?>/doc/employment01.php">채용정보</a></li>
            </ul>
        </div>
    </li>
</ul>