<?php
include_once('../../../common.php');
$num = 1;
$title = 'about';
include_once(G5_THEME_PATH . '/head.php');
?>

<main>
    <section class="about01_ceo">
        <div class="top">
            <img src="<?php echo G5_THEME_URL ?>/img/about/about_all_visual.jpg" alt="">
            <div class="t_txt">
                <h2>About 비락</h2>
                <p>고객만족을 넘어 고객가치를 실천하는 선도기업</p>
            </div>
        </div>
        <div class="inner nav">
            <ul class="ab_nav">
                <li class="home_gnb"><a href="/"><i class="xi-home"></i></a></li>
                <li class="head_gnb"><a href="#!">About 비락<i class="xi-caret-down-circle-o"></i></a>
                    <ul class="sub_nav">
                        <li><a href="<?php echo G5_THEME_URL ?>/doc/about01.php">About 비락</a></li>
                        <li><a href="<?php echo G5_THEME_URL ?>/doc/business01.php">BUSUNESS</a></li>
                        <li><a href="/bbs/board.php?bo_table=notice">News Room</a></li>
                        <li><a href="<?php echo G5_THEME_URL ?>/doc/employment01.php">인재채용</a></li>
                    </ul>
                </li>
                <li class="ab_gnb"><a href="#!">CI소개<i class="xi-caret-down-circle-o"></i></a>
                    <ul class="sub_nav">
                        <li><a href="<?php echo G5_THEME_URL ?>/doc/about01.php">CEO 인사말</a></li>
                        <li><a href="<?php echo G5_THEME_URL ?>/doc/about02.php">기업소개</a></li>
                        <li><a href="<?php echo G5_THEME_URL ?>/doc/about03.php">연혁</a></li>
                        <li><a href="<?php echo G5_THEME_URL ?>/doc/about04.php">CI소개</a></li>
                        <li><a href="<?php echo G5_THEME_URL ?>/doc/about05.php">오시는 길</a></li>
                    </ul>
                </li>
            </ul>

        </div>
    </section>
    <div class="inner tit" style="height: 200vh;padding: 100px 0 0 0;">
        <h2 style="text-align: center; font-size: 70px;">준비중입니다.</h2>
    </div>
</main>

<?php
include_once(G5_THEME_PATH . '/tail.php');
?>