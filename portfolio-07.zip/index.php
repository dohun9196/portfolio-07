<?php
if (!defined('_INDEX_'))
    define('_INDEX_', true);
if (!defined('_GNUBOARD_'))
    exit; // 개별 페이지 접근 불가

include_once(G5_THEME_PATH . '/head.php');
?>

<main>
    <section class="mainVisual">
        <div class="main_slide">
            <figure>slide01</figure>
            <figure>slide02</figure>
            <figure>slide03</figure>
        </div>
        <div class="sc_down">
            <a href="#!">
                <i class="xi-mouse"></i>
            </a>
        </div>
    </section>

    <section id="mainAbout" class="mainAbout sec">
        <div class="inner">
            <h2>About 비락</h2>
            <div class="about_box">
                <img src="<?php echo G5_THEME_URL ?>/img/main_page/main_sec01.jpg" alt="">
                <div class="desc_box">
                    <h3>고객가치를 최우선으로 하는 기업</h3>
                    <p>대한민국 대표 음료 기업, 주식회사 비락을 소개합니다</p>
                    <div class="more">
                        <a href="<?php echo G5_THEME_URL ?>/doc/about01.php">자세히보기</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="mainBusiness sec">
        <div class="inner">
            <h2>BUSINESS</h2>
        </div>
        <div class="flex_inner">
            <figure>
                <p>유제품</p>
                <img src="<?php echo G5_THEME_URL ?>/img/main_page/main_sec02.jpg" alt="">
                <div class="busi_cover"></div>
                <div class="more">
                    <a href="<?php echo G5_THEME_URL ?>/doc/business01.php">자세히보기</a>
                </div>
            </figure>
            <figure>
                <p>음료</p>
                <img src="<?php echo G5_THEME_URL ?>/img/main_page/main_sec03.jpg" alt="">
                <div class="busi_cover">
                    <div class="more">
                        <a href="<?php echo G5_THEME_URL ?>/doc/business02.php">자세히보기</a>
                    </div>
                </div>
            </figure>
            <figure>
                <p>OEM/ODM</p>
                <img src="<?php echo G5_THEME_URL ?>/img/main_page/main_sec04.jpg" alt="">
                <div class="busi_cover"></div>
                <div class="more">
                    <a href="#!">준비중...</a>
                </div>
            </figure>
            <figure>
                <p>해외사업</p>
                <img src="<?php echo G5_THEME_URL ?>/img/main_page/main_sec05.jpg" alt="">
                <div class="busi_cover"></div>
                <div class="more">
                    <a href="#!">준비중...</a>
                </div>
            </figure>
        </div>
    </section>

    <section class="mainNotice sec">
        <div class="notice_topbg">
            <div class="flex_inner">
                <div class="notice01 nobox">
                    <a href="/bbs/board.php?bo_table=contribution">
                        <div class="noticeTxt">
                            <strong>사회공헌활동</strong>
                            <p class="fir_p">관심과 나눔으로 꿈과 희망을 열어갑니다.</p>
                        </div>
                        <div class="noticeImg">
                            <img src="<?php echo G5_THEME_URL ?>/img/main_page/main-sec4-link-icon1.png" alt="">
                        </div>
                    </a>
                </div>
                <div class="notice02 nobox">
                    <a href="<?php echo G5_THEME_URL ?>/doc/employment01.php">
                        <div class="noticeTxt">
                            <strong>채용정보</strong>
                            <p>함께할 수 있는 우수한 인재를 모집합니다.</p>
                        </div>
                        <div class="noticeImg">
                            <img src="<?php echo G5_THEME_URL ?>/img/main_page/main-sec4-link-icon2.png" alt="">
                        </div>
                    </a>
                </div>
                <div class="notice03 nobox">
                    <a href="<?php echo G5_THEME_URL ?>/doc/about05.php">
                        <div class="noticeTxt">
                            <strong>오시는길</strong>
                            <p>비락에 오시는 길을 알려드립니다.</p>
                        </div>
                        <div class="noticeImg">
                            <img src="<?php echo G5_THEME_URL ?>/img/main_page/main-sec4-link-icon2.png" alt="">
                        </div>
                    </a>
                </div>
            </div>
        </div>
</main>

<?php
include_once(G5_THEME_PATH . '/tail.php');
?>
